import urllib


class ActionBatchLicensing(object):
    def __init__(self):
        super(ActionBatchLicensing, self).__init__()
        
